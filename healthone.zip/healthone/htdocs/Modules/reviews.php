<?php

function getReviews(int $id): array
{
    global $pdo;
    $sth = $pdo->prepare('SELECT users.first_name AS name reviews.description, reviews.rating, reviews.product_id
                            FROM reviews
                            LEFT JOIN users
                            ON reviews.user_id = users.id
WHERE product_id = ? ORDER BY id DESC ');
    $sth->bindParam(1, $id);
    $sth->execute();
    return $sth->fetchAll(PDO::FETCH_CLASS, 'Review');
}

function saveReview(int $userId, string $review, string $rating, int $productId): void
{
    global $pdo;
    $sth = $pdo->prepare('INSERT INTO reviews (name, description, rating, product_id, user_id) VALUES ("",?,?,?,?)');
    $sth->bindParam(1, $review);
    $sth->bindParam(2, $rating);
    $sth->bindParam(3, $productId);
    $sth->bindParam(4, $userId);
    $sth->execute();
}