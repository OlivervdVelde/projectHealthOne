<?php

function getAllCategories()
{
    global $pdo;

    $query = $pdo->prepare("SELECT * FROM category");
    $query->execute();
    $result = $query->fetchAll (PDO::FETCH_CLASS,'Category');
    return $result;
}

function getCategoryName(int $id)
{
        global $pdo;
        $query = $pdo->prepare("SELECT * FROM category");
        $query->execute();
        $result = $query->fetchAll(PDO::FETCH_ASSOC);

        return $result;
}