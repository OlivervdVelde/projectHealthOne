<?php
// TODO Zorg dat de methodes goed ingevuld worden met de juiste queries.
function getProducts(int $categoryId)
{
    global $pdo;

    $sth = $pdo->prepare('SELECT * FROM product WHERE category_id =?');
    $sth->bindParam(1, $categoryId);
    $sth->execute();
    return $sth->fetchAll(PDO::FETCH_CLASS, 'product');
}

function getProduct(int $productId)
{
    global $pdo;
    $sth = $pdo->prepare('SELECT * FROM product WHERE id=?');
    $sth->bindParam(1, $productId);
    $sth->execute();
    return $sth->fetchAll(PDO::FETCH_CLASS, 'Product')[0];
}

function getAllProducts():array
{
    global $pdo;
    $sth = $pdo->prepare('SELECT * FROM product ORDER BY category_id');
    $sth->execute();
    return $sth->fetchAll(PDO::FETCH_CLASS, 'Product');
}

function isPost()
{
    if ((isset($_POST['name'])) && (!empty($_POST['name'])) &&
        (isset($_POST['category'])) && (!empty($_POST['category'])) &&
        (isset($_POST['description'])) && (!empty($_POST['description'])) &&
        (isset($_FILES['fileToUpload'] ['tmp_name'])) && (!empty($_FILES['fileToUpload'] ['tmp_name']))) {
        return true;
    } else
        return false;
}

function fileupload()
{
    global $message;

    $allowed = ['gif', 'png', 'jpg'];
    $filename = $_FILES['fileToUpload']['name'];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    if (!in_array($ext, $allowed) || exif_imagetype($_FILES['fileToUpload'] ['tmp_name']) === false) {
        $message = "Sorry alleen gif, png of jpg files toegestaan";
        return false;
    }
    $target_dir = "img/categories/" . strtolower(getCategoryName((int)$_POST['category'])) . "/";
    $target_file = $_FILES["fileToUpload"]["name"];
    do {
        $target_file = $target_dir . md5($target_file) . ".$ext";
    } while (file_exists($target_file));

    if ($_FILES["fileToUpload"]["size"] > 500000) {
        $message= "Sorry, bestand is te groot.";
        return false;
    }

    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        return true;
    } else {
        $message= "Sorry, er is iets misgegaan.";
        return false;
    }
}

function getCategories():array
{
    global $pdo;
    $categories = $pdo->query('SELECT * FROM category')->fetchAll(PDO::FETCH_CLASS, 'Category');
    return $categories;
}