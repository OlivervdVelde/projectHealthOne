<!DOCTYPE html>
<html>
<?php
include_once('defaults/head.php');
?>

<body>

<div class="container">
    <?php
    include_once('defaults/header.php');
    include_once('defaults/menu.php');
    include_once('defaults/pictures.php');
    ?>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item"><a href="/categories">Categories</a></li>
        </ol>
    </nav>
    <div class="row gy-3 ">
        <?php global $products ?>
        <div class="col-sm-4 col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <a>
                        <img class="product-img img-responsive center-block" src='<?= "/img/$product->picture"?>'/>
                    </a>
                    <div class="card-title mb-3"><?= $product->name?></div>
                </div>
            </div>
        </div>
        <div class="col-sm-4 col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <div class="card-title mb-3"><b><?= $product->name?></b></div>
                    <div class="card-text "><?= $product->description?></div>
                </div>
            </div>
        </div>
        <div class="col-md-6 mt-sm-3 mt-md-0">
            <div class="card p-3">
                <p class="lead">Geef je mening over dit apparaat</p>
                <form method="post">
                    <div class="mb-3">
                        <label for="name" class="col-form-label">
                            Naam: <?= isset($_SESSION['name']) ? $_SESSION['name'] : "Unknown" ?>
                        </label>
                    </div>
                    <div class="mb-3">
                        <label for="name2" class="col-form-label">
                            Review:
                        </label>
                        <textarea class="form-control" name="review" id="name2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label  class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Waardering:</label>
                        <select class="custom-select mr-sm-2" name="rating" id="inlineFormCustomSelect">
                            <option selected value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

        <hr>
        <?php
        include_once('defaults/footer.php');

        ?>
    </div>

</body>
</html>