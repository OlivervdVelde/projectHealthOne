<!DOCTYPE html>
<html>
<?php
include_once(TEMPLATE_ROOT . '/defaults/head.php')
?>

<body>
    <a type="button" class="btn btn-success btn-sm px-3" href="/admin/add" >
        <i class="bi bi-plus-square">Voeg apparaat toe</i>
    </a>



<div class="container">
    <?php
    include_once(TEMPLATE_ROOT . '/defaults/header.php');
    include_once(TEMPLATE_ROOT . '/defaults/menu.php');
    include_once(TEMPLATE_ROOT . '/defaults/pictures.php');
    global $name, $products
    ?>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item"><a href="/categories">Categories</a></li>
        </ol>
    </nav>
    <div class="row gy-3 ">
        <?php global $products ?>
        <?php foreach ($products as $product):?>
            <div class="col-sm-4 col-md-3">
                <div class="card">
                    <div class="card-body text-center">
                        <a href="<?="/product/$product->id"?>">
                            <img class="product-img img-responsive center-block" src='<?= "/img/$product->picture"?>'/>
                        </a>
                        <div class="card-title mb-3"><?= $product->name?></div>
                    </div>

                </div>
            </div>
        <?php endforeach;?>

        <hr>
        <?php
        include_once(TEMPLATE_ROOT . '/defaults/footer.php');

        ?>
    </div>
</body>
</html>

