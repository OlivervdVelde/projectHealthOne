<!DOCTYPE html>
<html>
<?php
include_once('defaults/head.php');
?>

<body>

<div class="container">
    <?php
    include_once('defaults/header.php');
    include_once('defaults/menu.php');
    include_once('defaults/pictures.php');
    ?>
    <form class="row g-3">
        <div class="col-md-6">
            <label for="inputEmail" class="form-label">Email</label>
            <input type="email" class="form-control" id="inputEmail">
        </div>
        <div class="col-md-6">
            <label for="inputPassword" class="form-label">Password</label>
            <input type="password" class="form-control" id="inputPassword">
        </div>
        <div class="col-md-6">
            <label for="inputFirstname" class="form-label">First name</label>
            <input type="text" class="form-control" id="inputFirstname">
        </div>
        <div class="col-md-6">
            <label for="inputLastname" class="form-label">Last name</label>
            <input type="text" class="form-control" id="inputLastname">
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Register</button>
        </div>
    </form>
</div>
