<?php

class User
{
    Public $id;
    Public $email;
    Public $password;
    Public $first_name;
    Public $last_name;
    Public $role;

    public function _construct()
    {
        settype($this->id, 'integer');
    }
}