<?php

class Review
{
    Public $id;
    Public $name;
    Public $date;
    Public $description;
    Public $rating;
    Public $product_id;
    Public $user_id;

    public function __construct()
    {
        settype($this->id, 'integer');
        settype($this->rating, 'integer');
        settype($this->product_id, 'integer');
        settype($this->user_id, 'integer');
    }
}
