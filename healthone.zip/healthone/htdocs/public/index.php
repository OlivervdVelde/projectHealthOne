<?php
require '../Modules/Categories.php';
require '../Modules/Products.php';
require '../Modules/users.php';
require '../Modules/Database.php';
require '../Modules/Registration.php';

define("DOC_ROOT", realpath(dirname(__DIR__)));
define("TEMPLATE_ROOT", realpath(DOC_ROOT . "/Templates"));

$request = $_SERVER['REQUEST_URI'];
$params = explode("/", $request);
$title = "HealthOne";
$titleSuffix = "";
session_start();

switch ($params[1]) {
    case 'categories':
        $titleSuffix = ' | Categories';
        $categories = getCategories();
        include_once "../Templates/categories.php";
        break;

    case 'login':
        $titleSuffix = ' | Login';

        if (isset($_POST['login'])) {
            $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
            $password = filter_input(INPUT_POST, 'password');
            $user = checkLogin($email, $password);
            if ($user == false) {
                $error ['title'] = "Incorrect!";
                $error ['message'] = "Incorrect credentials used";
            } else {
                $_SESSION['login'] = true;
                $_SESSION['role'] = $user->role;
                $_SESSION['email'] = $user->email;
                $_SESSION['name'] = "$user->first_name $user->last_name";
                $_SESSION['id'] = $user->id;
            }

        }
        include_once "../Templates/login.php";
        switch ($result) {
            case 'ADMIN':
                header("Location: /Templates/admin.php");
                break;
            case 'member':
                $message = "Inlog correct!";
                break;
            case 'FAILURE':
                $message = "Email of password niet correct ingevuld!";
                include_once "../Templates/login.php";
                break;
            case 'INCOMPLETE':
                $message = "Formulier niet volledig ingevuld!";
                include_once "../Templates/login.php";
                break;
        }
        break;
    case 'logout':
        session_destroy();
        header("location:  /");
        break;


    case 'category':
        $titleSuffix = '| Category';
        if (isset ($_GET['id'])) {
            $categoryId = $_GET['id'];
            $name = getCategoryName($categoryId);
            $products = getProducts($categoryId);
            include_once "../Templates/products.php";
        } else {
            $titleSuffix = '| Home';
            include_once "../Templates/home.php";
        }
        break;
    case 'product':
        if (isset($_GET['id'])) {
            $productId = $_GET['id'];
            $product = getProduct($productId);
            $name = getCategoryName($product->category_id);
            $titleSuffix = ' | ' . $product->name;
            include_once "../Templates/product.php";
        }

        if (isset($_POST['addReview'])) {
            if (isset($_SESSION['id'])) {
                $review = filter_input(INPUT_POST, "review", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                $rating = filter_input(INPUT_POST, "rating", FILTER_VALIDATE_INT);
                if (!isset($rating) || $rating == false) {
                    $error['title'] = "oops!";
                    $error['message'] = "Something went wrong.";
                } else {
                    saveReview($_SESSION['id'], $review, $rating, $productId);
                    $success['title'] = "Thanks!";
                    $success['message'] = "Your review has been added.";
                }
            } else {
                $error['title'] = "oops!";
                $error['message'] = "Please login.";
            }

        }
        $reviews = getReviews($productId);
        include_once "../Templates/product.php";
        break;

    case 'register':
        $titleSuffix = ' | Register';

        if(isset($_POST['register'])) {

            $result = makeRegistration();
            switch ($result) {
                case 'SUCCESS':
                    header("Location: /home");
                    break;
                case 'INCOMPLETE':
                    $message="Niet alle velden correct ingevuld";
                    include_once "../Templates/register.php";
                    break;
                case 'EXIST':
                    $message = "Gebruiker bestaat al";
                    include_once "../Templates/register.php";
                    break;
            }
        }
        else {
            include_once "../Templates/register.php";
        }
        break;
    case 'admin':
        include_once 'admin.php';
        break;
    case 'member':
        include_once 'member.php';
        break;

    case 'add':
        if (isPost()) {
            if (fileupload()) {
                saveProduct($_POST['name'], $_POST['category'], $_POST['description'], $message);
                header("location: /admin/products");
            } else {
                include_once "../Templates/admin/addproduct.php";
            }
        } else {
            include_once "../Templates/admin/addproduct.php";
        }
        break;
    default:
        $titleSuffix = ' | Home';
        include_once "../Templates/home.php";
}

function getTitle() {
    global $title, $titleSuffix;
    return $title . $titleSuffix;
}
