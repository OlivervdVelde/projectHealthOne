<?php

global $params;

if (isset($_SESSION['role']) && $_SESSION['role'] === 'member'){
    $user=$_SESSION['role'];
    switch ($params[2]) {
        case 'home':
            include_once '../Templates/member/home.php';
            break;
    }
} else {
    include_once '../Templates/home.php';
}