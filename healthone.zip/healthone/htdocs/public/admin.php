<?php

global $params;

if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'){
    switch ($params[2]) {
        case 'products':
            $products = getAllProducts();
            include_once '../Templates/admin/products.php';
            break;
    }
} else {
        include_once '../Templates/home.php';
}